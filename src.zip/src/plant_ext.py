"""Additional DFN plant simulations (beyond scenarios A-E):

  F      degradation-mode aging on top of scenario D: loss of cyclable inventory (5 % LFP, 6 % Na-ion of the
         maximum negative-electrode concentration) -> OCV-SOC distortion, and halved particle diffusivities and
         exchange-current densities -> altered polarisation.  Outputs plant_drv_F_<chem>.npz and the true C/50
         capacities fullcap_F_<chem>.npz.
  A-inf, D-inf
         voltage-limited informative profile: preconditioning + n1 UDDS (Na-ion SOC about 35 %) + C/4 charge
         (at most 60 min, terminated when either terminal voltage incl. the added series resistance reaches
         4.2 V Na-ion / 3.65 V LFP) + 20 min rest + 30 UDDS. Two passes: pass 1 finds the termination time from
         the Na-ion cell, pass 2 simulates both cells. Outputs plant_inf2_<A|D>_<chem>.npz and inf2_<A|D>.json.

Usage:  python plant_ext.py F          (about 20-40 min)
        python plant_ext.py A D        (informative profiles; about 30-60 min each)
"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, pybamm, time, warnings, json
warnings.filterwarnings("ignore"); pybamm.set_logging_level("ERROR")
from plant import params, drive_profile, QNOM
from run_plants import SCEN

R0M = {"LFP": 0.0395, "Na": 0.290}   # mean identified ohmic resistance (Ohm), as used in evaluate.py
VMAX = {"LFP": 3.65, "Na": 4.2}
N1 = {"A": 13, "D": 8}               # UDDS repetitions before charging (Na-ion SOC about 35 %)

def scale_fn(f, k):
    if callable(f): return lambda *a: k * f(*a)
    return k * f

def params_mod(chem, theta, lli=0.0, kin=1.0):
    p, m = params(chem, theta)
    if lli:   # loss of cyclable inventory: fraction of the maximum negative-electrode concentration removed
        p["Initial concentration in negative electrode [mol.m-3]"] -= lli * p["Maximum concentration in negative electrode [mol.m-3]"]
    if kin != 1.0:
        for key in ["Negative particle diffusivity [m2.s-1]", "Positive particle diffusivity [m2.s-1]",
                    "Negative electrode exchange-current density [A.m-2]", "Positive electrode exchange-current density [A.m-2]"]:
            p[key] = scale_fn(p[key], kin)
    return p, m

def run(chem, p, m, t, I):
    """chunked DFN simulation (600 s steps); stops at 2.0 V or when the solver cannot proceed"""
    p["Current function [A]"] = pybamm.Interpolant(t, I, pybamm.t, interpolator="linear")
    if chem == "Na":
        p["Lower voltage cut-off [V]"] = 1.0; p["Upper voltage cut-off [V]"] = 4.5
    else:
        p["Lower voltage cut-off [V]"] = 1.5; p["Upper voltage cut-off [V]"] = 4.2
    sim = pybamm.Simulation(m, parameter_values=p, solver=pybamm.CasadiSolver(mode="fast" if chem == "Na" else "safe", dt_max=60))
    sol = None; status = "complete"
    for k in range(int(t[-1] // 600)):
        try: sol = sim.step(dt=600, npts=601, starting_solution=sol, save=True)
        except Exception: status = f"solver stopped at step {k}"; break
        if sol["Voltage [V]"].entries[-1] < 2.0: status = "reached 2.0 V"; break
    tt = sol.t; v = sol["Voltage [V]"].entries; q = sol["Discharge capacity [A.h]"].entries
    _, idx = np.unique(np.round(tt, 6), return_index=True); tt, v, q = tt[idx], v[idx], q[idx]
    ti = np.arange(0, int(tt[-1]) + 1, dtype=float)
    return ti, np.interp(ti, tt, v), np.interp(ti, tt, q), status

def full_cap(chem, p, m, C=1/50):
    p["Current function [A]"] = QNOM * C
    s = pybamm.Simulation(m, parameter_values=p).solve([0, 1.3 * 3600 / C])
    return float(s["Discharge capacity [A.h]"].entries[-1]), s["Voltage [V]"].entries, s["Discharge capacity [A.h]"].entries

def udds_cycle():
    t, I, npre = drive_profile("UDDS", n_rep=1)
    return I[npre:]

def informative_profile(n1, tch, n2=30):
    I_pre = np.r_[np.full(int(0.15 * 10 * 3600), QNOM / 10), np.zeros(1800)]
    I = np.r_[I_pre, np.tile(udds_cycle(), n1), np.full(int(tch), -QNOM / 4), np.zeros(1200), np.tile(udds_cycle(), n2)]
    return np.arange(len(I), dtype=float), I, len(I_pre), len(I_pre) + n1 * len(udds_cycle())

def case_F():
    thL, thN, _, _ = SCEN["D"]
    for chem, th, lli in (("LFP", thL, 0.05), ("Na", thN, 0.06)):
        t0 = time.time()
        p, m = params_mod(chem, th, lli, 0.5); Q, V, q = full_cap(chem, p, m)
        np.savez(os.path.join(PLANT, f"fullcap_F_{chem}.npz"), V=V, q=q, Q=Q)
        t, I, npre = drive_profile("UDDS", n_rep=34)
        p, m = params_mod(chem, th, lli, 0.5); ti, v, qq, st = run(chem, p, m, t, I)
        np.savez(os.path.join(PLANT, f"plant_drv_F_{chem}.npz"), t=ti, v=v, q=qq, I=I[:len(ti)], npre=npre)
        print("F", chem, "Q_C/50 =", round(Q, 4), "Ah;", st, "; wall", round(time.time() - t0), "s", flush=True)

def case_inf(sc):
    thL, thN, dRL, dRN = SCEN[sc]; t0 = time.time()
    t, I, npre, tc0 = informative_profile(N1[sc], 3600, n2=0)          # pass 1: Na-ion up to the end of a 60 min window
    p, m = params("Na", thN); ti, v, q, st = run("Na", p, m, t[:tc0 + 3601], I[:tc0 + 3601])
    VN = v - I[:len(ti)] * dRN * R0M["Na"]
    over = np.where((np.arange(len(ti)) >= tc0) & (VN >= VMAX["Na"]))[0]
    tch = (over[0] - tc0) if len(over) else 3600
    t, I, npre, tc0 = informative_profile(N1[sc], tch)                # pass 2: both cells with the final profile
    res = {}
    for chem, th, dR in (("Na", thN, dRN), ("LFP", thL, dRL)):
        p, m = params(chem, th); ti, v, q, st = run(chem, p, m, t, I)
        np.savez(os.path.join(PLANT, f"plant_inf2_{sc}_{chem}.npz"), t=ti, v=v, q=q, I=I[:len(ti)], npre=npre)
        Vt = v - I[:len(ti)] * dR * R0M[chem]; seg = slice(tc0, min(len(ti), tc0 + int(tch) + 1))
        res[chem] = dict(status=st, t_end=float(ti[-1]), Vmax_charge=float(Vt[seg].max()), Vmax_all=float(Vt.max()))
    res.update(tch=float(tch), tc0=int(tc0), n1=N1[sc])
    json.dump(res, open(os.path.join(PLANT, f"inf2_{sc}.json"), "w"))
    print(sc, "charge duration", tch, "s;", res, "; wall", round(time.time() - t0), "s", flush=True)

if __name__ == "__main__":
    for a in sys.argv[1:]:
        case_F() if a == "F" else case_inf(a)
