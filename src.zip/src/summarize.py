"""Summary statistics (mean, std) of the original Monte Carlo comparison -> data/results/summary.json."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import json, numpy as np
from run_plants import SCEN
SC = [("A","UDDS"),("B","UDDS"),("C","UDDS"),("D","UDDS"),("E","UDDS"),("C","US06")]
M = ["CC","EKF-L","IND-AA","X-EKF","IND-R","AA-X-EKF"]
S = {}
for s,c in SC:
    R = json.load(open(os.path.join(RESULTS, "montecarlo", f"mc_{s}_{c}.json"))); key = f"{s}-{c}"; S[key] = {}
    for m in M:
        a = R[m]; f = lambda k: np.array([r[k] if r[k] is not None else np.nan for r in a], float)
        S[key][m] = {k: [float(np.nanmean(f(k))), float(np.nanstd(f(k)))] for k in ["rmse","maxae","rdc_rmse","rmseN","QN","QL"]}
        S[key][m]["absfinal"] = [float(np.mean(np.abs(f("final")))), float(np.std(np.abs(f("final"))))]
json.dump(S, open(os.path.join(RESULTS, "summary.json"),"w"), indent=1)
for k in S:
    print(k, " | ".join(f"{m}: {S[k][m]['rmse'][0]:.2f}±{S[k][m]['rmse'][1]:.2f}" for m in M))
