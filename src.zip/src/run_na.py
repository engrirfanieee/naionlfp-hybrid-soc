import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, time, pybamm, warnings
warnings.filterwarnings("ignore"); pybamm.set_logging_level("ERROR")
from plant import params, drive_profile
from run_plants import SCEN
for job in sys.argv[1:]:
    name, cycle = job.split(":")
    th = SCEN[name][1]
    t, I, npre = drive_profile(cycle=cycle, n_rep=34 if cycle == "UDDS" else 80)
    p, m = params("Na", th)
    p["Current function [A]"] = pybamm.Interpolant(t, I, pybamm.t, interpolator="linear")
    p["Lower voltage cut-off [V]"] = 1.0; p["Upper voltage cut-off [V]"] = 4.5   # limits checked in post-processing
    sim = pybamm.Simulation(m, parameter_values=p, solver=pybamm.CasadiSolver(mode="fast", dt_max=60))
    t0 = time.time(); sol = None; status = "complete"
    for k in range(int(t[-1] // 600)):
        try:
            sol = sim.step(dt=600, npts=601, starting_solution=sol, save=True)
        except Exception as e:
            status = f"solver stopped at step {k}: {str(e)[:60]}"; break
        if sol["Voltage [V]"].entries[-1] < 2.0: status = "reached 2.0 V"; break
    tt = sol.t; v = sol["Voltage [V]"].entries; q = sol["Discharge capacity [A.h]"].entries
    _, idx = np.unique(np.round(tt, 6), return_index=True); tt, v, q = tt[idx], v[idx], q[idx]
    ti = np.arange(0, int(tt[-1]) + 1, dtype=float)
    vi = np.interp(ti, tt, v); qi = np.interp(ti, tt, q)
    np.savez(os.path.join(PLANT, f"plant_{name}_{cycle}_Na.npz"), t=ti, v=vi, q=qi, I=I[:len(ti)], npre=npre)
    print(job, "Na t_end", ti[-1], "Ah", qi[-1], "Vmin", vi.min(), "Vmax", vi.max(), status, "wall", round(time.time()-t0), flush=True)
