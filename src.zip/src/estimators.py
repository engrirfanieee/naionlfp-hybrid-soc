"""State estimators for a series-connected sodium-ion / LFP hybrid string (2RC ECMs, 1 s sampling)."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json
P = json.load(open(os.path.join(MODEL, "ecm2_params.json")))
RMSE_MAX = 0.025   # pulse-fit acceptance threshold [V]

class Cell:
    def __init__(self, chem):
        d = P[chem]
        self.g = np.array(d["soc"]); self.ocv = np.array(d["ocv"]); self.docv = np.gradient(self.ocv, self.g)
        r = np.array(d["ecm2"]); r = r[r[:, 6] < RMSE_MAX]; r = r[np.argsort(r[:, 0])]
        self.tab = r[:, :6]; self.Q = d["Q"]
        # smooth SOC dependence: quadratic least-squares fit of each parameter over the accepted pulse fits
        self.coef = [np.polyfit(r[:, 0], r[:, j], 2) for j in range(1, 6)]
        self.lo = [max(1e-4, 0.5*r[:, j].min()) for j in range(1, 6)]
        self.smin, self.smax = r[:, 0].min(), r[:, 0].max()
    def U(self, s):  return np.interp(s, self.g, self.ocv)
    def dU(self, s): return np.interp(s, self.g, self.docv)
    def p(self, s):  # R0, R1, tau1, R2, tau2 (quadratic in SOC, held constant outside the identified range)
        z = min(max(s, self.smin), self.smax)
        return [max(lo, float(np.polyval(c, z))) for c, lo in zip(self.coef, self.lo)]
    def dR0(self, s, h=1e-3): return (self.p(s+h)[0]-self.p(s-h)[0])/(2*h)

NA, LF = Cell("Na"), Cell("LFP")
CELLS = {"N": NA, "L": LF}

def coulomb(Im, dt, s0):
    return s0 - np.cumsum(np.r_[0, Im[:-1]])*dt/3600/LF.Q

class EKF:
    """EKF over named states: s{c}, a{c}, c{c} (SOC, RC1, RC2 voltages of cell c in {N,L}),
    b (current-sensor offset), g{c} (inverse capacity scale), r{c} (ohmic-resistance scale)."""
    def __init__(self, keys, x0, P0, Qd, meas, Rm):
        self.k = {n: i for i, n in enumerate(keys)}; self.x = np.array(x0, float)
        self.P = np.diag(P0).astype(float); self.Qd = np.diag(Qd).astype(float)
        self.meas = meas; self.Rm = np.diag(Rm).astype(float)
    def g(self, n, d): return self.x[self.k[n]] if n in self.k else d
    def step(self, Im, z, dt=1.0):
        k, x = self.k, self.x.copy(); n = len(x); F = np.eye(n)
        b = self.g("b", 0.0); Ie = Im - b
        for c, cell in CELLS.items():
            if "s"+c not in k: continue
            gam = self.g("g"+c, 1.0); s = x[k["s"+c]]
            R0, R1, t1, R2, t2 = cell.p(s); a1, a2 = np.exp(-dt/t1), np.exp(-dt/t2)
            x[k["s"+c]] = s - dt*Ie*gam/(3600*cell.Q)
            if "b" in k: F[k["s"+c], k["b"]] = dt*gam/(3600*cell.Q)
            if "g"+c in k: F[k["s"+c], k["g"+c]] = -dt*Ie/(3600*cell.Q)
            for vk, a, R in (("a"+c, a1, R1), ("c"+c, a2, R2)):
                x[k[vk]] = a*x[k[vk]] + R*(1-a)*Ie; F[k[vk], k[vk]] = a
                if "b" in k: F[k[vk], k["b"]] = -R*(1-a)
        self.P = F@self.P@F.T + self.Qd
        H = np.zeros((len(self.meas), n)); h = np.zeros(len(self.meas))
        for i, c in enumerate(self.meas):
            cell = CELLS[c]; s = x[k["s"+c]]; rho = self.g("r"+c, 1.0); R0 = cell.p(s)[0]
            h[i] = cell.U(s) - Ie*R0*rho - x[k["a"+c]] - x[k["c"+c]]
            H[i, k["s"+c]] = cell.dU(s) - Ie*rho*cell.dR0(s)
            H[i, k["a"+c]] = H[i, k["c"+c]] = -1.0
            if "b" in k: H[i, k["b"]] = R0*rho
            if "r"+c in k: H[i, k["r"+c]] = -Ie*R0
        Rm = self.Rm.copy()
        for i, c in enumerate(self.meas):   # OCV-slope-aware measurement weighting (applied to every EKF variant)
            sl = abs(CELLS[c].dU(x[k["s"+c]]))
            Rm[i, i] *= max(1.0, (S_REF/max(sl, 1e-6))**2)
            sc = x[k["s"+c]]; cell = CELLS[c]   # outside the SOC window in which the ECM was identified
            if sc < cell.smin - 0.02 or sc > cell.smax + 0.05: Rm[i, i] *= OUT_OF_RANGE
        z = np.array(z, float)
        for i in range(len(self.meas)):   # missing measurement (NaN): no update from this channel
            if np.isnan(z[i]): Rm[i, i] = 1e12; z[i] = h[i]
        S = H@self.P@H.T + Rm; K = self.P@H.T@np.linalg.inv(S)
        self.x = x + K@(z - h); IKH = np.eye(n) - K@H
        self.P = IKH@self.P@IKH.T + K@Rm@K.T
        for c in CELLS:   # physical bounds (state projection)
            if "s"+c in k: self.x[k["s"+c]] = np.clip(self.x[k["s"+c]], -0.05, 1.05)
            if "g"+c in k: self.x[k["g"+c]] = np.clip(self.x[k["g"+c]], G_LO, G_HI)
            if "r"+c in k: self.x[k["r"+c]] = np.clip(self.x[k["r"+c]], R_LO, R_HI)
        return self.x.copy(), np.sqrt(np.diag(self.P))

# ---- tuning (per 1-s step) ----
SIG = {"N": 0.040, "L": 0.008}
S_REF = 1.0   # reference OCV slope [V per unit SOC] = 10 mV per % SOC
OUT_OF_RANGE = 100.0     # measurement std incl. ECM structural error [V]
Q_S, Q_V, Q_B, Q_G, Q_R = 1e-10, 1e-7, 1e-13, 1e-13, 1e-11
P_S, P_V, P_B, P_G, P_R = 0.2**2, 1e-4, 0.01**2, 0.3**2, 0.5**2
def cellkeys(c): return ["s"+c, "a"+c, "c"+c]
def make(method, sN0, sL0):
    if method == "EKF-L":
        return EKF(cellkeys("L"), [sL0, 0, 0], [P_S, P_V, P_V], [Q_S, Q_V, Q_V], ["L"], [SIG["L"]**2])
    if method == "EKF-L+b":
        return EKF(cellkeys("L")+["b"], [sL0, 0, 0, 0], [P_S, P_V, P_V, P_B], [Q_S, Q_V, Q_V, Q_B], ["L"], [SIG["L"]**2])
    base_k = cellkeys("N") + cellkeys("L") + ["b"]
    base_x = [sN0, 0, 0, sL0, 0, 0, 0]; base_P = [P_S, P_V, P_V, P_S, P_V, P_V, P_B]; base_Q = [Q_S, Q_V, Q_V, Q_S, Q_V, Q_V, Q_B]
    if method == "X-EKF":
        return EKF(base_k, base_x, base_P, base_Q, ["N", "L"], [SIG["N"]**2, SIG["L"]**2])
    if method == "IND-R":     # independent, resistance-adaptive, nominal capacities, NO offset state.
        # No shared state: the joint covariance stays block-diagonal, i.e. two separate filters.
        kk = cellkeys("N") + cellkeys("L")
        return EKF(kk + ["rN", "rL"], base_x[:6] + [1, 1], base_P[:6] + [P_R, P_R],
                   base_Q[:6] + [Q_R, Q_R], ["N", "L"], [SIG["N"]**2, SIG["L"]**2])
    if method == "X-EKF-R":   # coupled through the shared offset b, resistance-adaptive, nominal capacities
        return EKF(base_k + ["rN", "rL"], base_x + [1, 1], base_P + [P_R, P_R],
                   base_Q + [Q_R, Q_R], ["N", "L"], [SIG["N"]**2, SIG["L"]**2])
    if method == "AA-X-EKF":   # proposed: coupled through the shared current-sensor offset
        return EKF(base_k + ["gN", "gL", "rN", "rL"], base_x + [1, 1, 1, 1], base_P + [P_G, P_G, P_R, P_R],
                   base_Q + [Q_G, Q_G, Q_R, Q_R], ["N", "L"], [SIG["N"]**2, SIG["L"]**2])
    if method == "IND-AA":     # ablation: same adaptive states, no shared offset (two independent filters)
        kk = cellkeys("N") + cellkeys("L")
        return EKF(kk + ["gN", "gL", "rN", "rL"], base_x[:6] + [1, 1, 1, 1], base_P[:6] + [P_G, P_G, P_R, P_R],
                   base_Q[:6] + [Q_G, Q_G, Q_R, Q_R], ["N", "L"], [SIG["N"]**2, SIG["L"]**2])
    raise ValueError(method)

G_LO, G_HI, R_LO, R_HI = 0.8, 2.0, 0.5, 3.0   # projection bounds of the capacity and resistance scales

def make_single(c, sc0, adaptive=True, offset=True):
    """single-cell filter for cell c with its own (non-shared) current-offset state (IND-AA-b ablation)"""
    k = cellkeys(c) + (["b"] if offset else []) + (["g"+c, "r"+c] if adaptive else [])
    x = [sc0, 0, 0] + ([0] if offset else []) + ([1, 1] if adaptive else [])
    P0 = [P_S, P_V, P_V] + ([P_B] if offset else []) + ([P_G, P_R] if adaptive else [])
    Qd = [Q_S, Q_V, Q_V] + ([Q_B] if offset else []) + ([Q_G, Q_R] if adaptive else [])
    return EKF(k, x, P0, Qd, [c], [SIG[c]**2])
