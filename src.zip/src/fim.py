"""Local identifiability analysis (Section 3.7, Table 4, Fig. 3).
Fisher information of the estimator's own ECM pair for the 11 quantities that correspond to the 11 EKF states:
initial SOCs, shared current offset, capacity and resistance scales, and the four initial polarisation voltages
(nuisance parameters). Sensitivities by central finite differences of the open-loop model; output errors weighted
by the nominal measurement standard deviations (40 mV Na-ion, 8 mV LFP); prior of Table 3 added.
Each profile is truncated to the evaluated window of its DFN plant run (from the start of the drive to the plant
termination); the profile with rests has no plant run and is truncated at the same discharged charge as UDDS.
Reported values are posterior standard deviations, i.e. square roots of the Cramer-Rao bound.
Output: data/results/fim.json.   Usage: python fim.py   (a few minutes)"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json
import estimators as E
import evaluate_ext as V
from plant import drive_profile

def udds_with_rests(n_rep=34, every=3, rest=1200):
    """UDDS repetitions with a 20 min rest after every third repetition"""
    t, I, npre = drive_profile("UDDS", n_rep=1); Ic = I[npre:]; seg = []
    for i in range(n_rep):
        seg.append(Ic)
        if (i+1) % every == 0: seg.append(np.zeros(rest))
    return np.concatenate(seg)
NAMES = ["zN0", "zL0", "b", "gN", "gL", "rN", "rL", "v1N", "v2N", "v1L", "v2L"]
SCALE = np.array([0.01, 0.01, 1e-3, 0.01, 0.01, 0.01, 0.01, 1e-3, 1e-3, 1e-3, 1e-3])
PRIOR_SD = np.array([0.2, 0.2, 0.01, 0.3, 0.3, 0.5, 0.5, 0.01, 0.01, 0.01, 0.01])
SIG = np.array([E.SIG["N"], E.SIG["L"]])

def simulate(I, p, dt=1.0):
    zN, zL, b, gN, gL, rN, rL, a1N, a2N, a1L, a2L = p
    x = {"N": [zN, a1N, a2N], "L": [zL, a1L, a2L]}; g = {"N": gN, "L": gL}; r = {"N": rN, "L": rL}
    Y = np.empty((len(I), 2))
    for k, Im in enumerate(I):
        Ie = Im - b
        for j, (c, cell) in enumerate((("N", E.NA), ("L", E.LF))):
            s, v1, v2 = x[c]; R0, R1, t1, R2, t2 = cell.p(s)
            Y[k, j] = cell.U(s) - Ie*R0*r[c] - v1 - v2
            a1, a2 = np.exp(-dt/t1), np.exp(-dt/t2)
            x[c] = [s - dt*Ie*g[c]/(3600*cell.Q), a1*v1 + R1*(1-a1)*Ie, a2*v2 + R2*(1-a2)*Ie]
    return Y

def sens(I, p0, idx):
    S = np.empty((len(I), 2, len(idx)))
    for n, i in enumerate(idx):
        h = SCALE[i]*0.5; pp = np.array(p0, float); pm = pp.copy(); pp[i] += h; pm[i] -= h
        S[:, :, n] = (simulate(I, pp) - simulate(I, pm))/(2*h)*SCALE[i]
    return S

def summarize(S, idx):
    J = np.einsum("kji,kjl,j->il", S, S, 1/SIG**2)
    C = np.linalg.inv(J + np.diag((SCALE[idx]/PRIOR_SD[idx])**2)); sd = np.sqrt(np.diag(C)); R = C/np.outer(sd, sd)
    nm = [NAMES[i] for i in idx]; ix = {n: k for k, n in enumerate(nm)}
    out = dict(sd={n: float(sd[k]) for n, k in ix.items()}, corr_b_gN=float(R[ix["b"], ix["gN"]]), corr_b_gL=float(R[ix["b"], ix["gL"]]),
               corr_gN_gL=float(R[ix["gN"], ix["gL"]]))
    ev = np.linalg.eigvalsh(J); out["cond_data"] = float(ev.max()/max(ev.min(), 1e-300))
    return out

FULL = list(range(11)); COND = list(range(7))
if __name__ == "__main__":
    out = {}
    for sc in ("A", "D"):
        D = V.load(sc); k0 = D["k0"]; thL, thN = D["thL"], D["thN"]
        f, (thL, thN, dRL, dRN, QL, QN) = V.case(sc)
        p0 = [D["sN"][k0], D["sL"][k0], 0.0, 1/thN, 1/thL, 1+dRN, 1+dRL, 0, 0, 0, 0]
        Iu = D["I"][k0:]
        Ir = udds_with_rests(); Ir = Ir[:np.searchsorted(np.cumsum(Ir), Iu.sum())]   # same discharged charge
        Di = V.load(sc + "-inf"); Ii = Di["I"][Di["k0"]:]
        p0i = [Di["sN"][Di["k0"]], Di["sL"][Di["k0"]]] + p0[2:]
        for pname, I, pp in (("UDDS", Iu, p0), ("UDDS+rests", Ir, p0), ("UDDS+charge+rest", Ii, p0i)):
            S = sens(np.asarray(I, float), pp, FULL)
            r = summarize(S, FULL); r["hours"] = len(I)/3600
            r["conditional_7"] = summarize(S[:, :, :7], COND)
            out[f"{sc}|{pname}"] = r; print(sc, pname, round(r["hours"], 2), {k: round(v, 3) for k, v in r["sd"].items()}, round(r["corr_b_gN"], 3), round(r["corr_b_gL"], 3), "| 7p:", round(r["conditional_7"]["corr_b_gN"], 3), round(r["conditional_7"]["corr_b_gL"], 3), flush=True)
        if sc == "A":
            Z = np.c_[D["sN"][k0:], D["sL"][k0:]]; win = []
            # true polarisation states at window start are taken from the open-loop model at the true parameters
            for s0 in range(0, len(Iu) - 3600, 1800):
                pw = [Z[s0, 0], Z[s0, 1]] + p0[2:]
                S = sens(np.asarray(Iu[s0:s0+3600], float), pw, FULL); r = summarize(S, FULL); rc = summarize(S[:, :, :7], COND)
                win.append(dict(t_h=s0/3600, zN=float(Z[s0:s0+3600, 0].mean()), zL=float(Z[s0:s0+3600, 1].mean()),
                                sd_zN=r["sd"]["zN0"], sd_zL=r["sd"]["zL0"], sd_zN_7=rc["sd"]["zN0"], sd_zL_7=rc["sd"]["zL0"]))
                print({k: round(v, 4) for k, v in win[-1].items()}, flush=True)
            out["A|windows"] = win
    json.dump(out, open(os.path.join(RESULTS, "fim.json"), "w"), indent=1)
