import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from estimators import NA, LF
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8.5,"axes.linewidth":0.8})
P=json.load(open(os.path.join(MODEL, "ecm2_params.json")))
c={"LFP":"#1f4e79","Na":"#b03a2e"}; lab={"LFP":"LFP/graphite","Na":"NVPF/hard carbon"}; cell={"LFP":LF,"Na":NA}
fig,ax=plt.subplots(1,3,figsize=(7.2,2.45))
for ch in ["LFP","Na"]:
    s=np.array(P[ch]["soc"]); o=np.array(P[ch]["ocv"])
    ax[0].plot(s*100,o,color=c[ch],lw=1.5,label=lab[ch]+" OCV")
    ax[0].plot(s*100,P[ch]["ocv_dis"],color=c[ch],lw=0.8,ls="--")
    d=np.abs(np.gradient(o,s))/100*1000; m=(s>0.02)&(s<0.98)
    ax[1].semilogy(s[m]*100,d[m],color=c[ch],lw=1.4,label=lab[ch])
    z=np.linspace(cell[ch].smin,cell[ch].smax,50)
    ax[2].plot(z*100,[cell[ch].p(v)[0]*1000 for v in z],color=c[ch],lw=1.4)
    r=np.array(P[ch]["ecm2"]); ok=r[:,6]<0.025
    ax[2].plot(r[ok,0]*100,r[ok,1]*1000,"o",color=c[ch],ms=3.5)
    ax[2].plot(r[~ok,0]*100,r[~ok,1]*1000,"x",color=c[ch],ms=5,mew=1.2)
ax[1].axhline(10,color="0.4",lw=0.8,ls=":"); ax[1].text(52,11.5,r"$S_{\rm ref}$",fontsize=8,color="0.3")
ax[0].set_xlabel("SOC (%)"); ax[0].set_ylabel("Voltage (V)"); ax[0].legend(frameon=False,fontsize=7,loc="lower right")
ax[1].set_xlabel("SOC (%)"); ax[1].set_ylabel("|dOCV/dSOC| (mV per % SOC)"); ax[1].legend(frameon=False,fontsize=7,loc="lower left")
ax[2].set_xlabel("SOC (%)"); ax[2].set_ylabel(r"$R_0$ (m$\Omega$)"); ax[2].set_yscale("log")
for a,t in zip(ax,"abc"): a.text(-0.24,1.02,f"({t})",transform=a.transAxes,fontweight="bold")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Figure_2.pdf")); fig.savefig(os.path.join(FIG, "Figure_2.png"),dpi=300)
