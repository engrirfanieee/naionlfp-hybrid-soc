import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
S=json.load(open(os.path.join(RESULTS, "summary.json")))
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11})
fig=plt.figure(figsize=(12,4.6))
ax=fig.add_axes([0,0,0.52,1]); ax.set_xlim(0,100); ax.set_ylim(0,60); ax.axis("off")
def box(x,y,w,h,t,fc,fs=11):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.5,rounding_size=1.5",fc=fc,ec="k",lw=1))
    ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=fs)
def arr(a,b,t=None,c="k",tp=None):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle="-|>",mutation_scale=14,lw=1.4,color=c))
    if t: ax.text(*tp,t,ha="center",fontsize=10,color=c)
box(3,38,26,14,"Na-ion cell\n(sloped OCV,\nfaster aging)","#f6d5d1")
box(3,8,26,14,"LFP cell\n(flat OCV)","#d6e2f0")
box(40,23,22,14,"Shared current-\noffset estimate $\\hat b$","#fff6d5")
box(72,38,26,14,"Nominal reference:\nLFP SOC error\nup to 12.8 %","#f4cccc",fs=10.5)
box(72,8,26,14,"Aging-aware coupled\nEKF: LFP SOC error\n1.0–1.1 %","#d9ead3",fs=10.5)
arr((30,42),(40,33),"capacity/resistance\nmismatch",c="#b03a2e",tp=(46,42))
arr((63,33),(71,40),"offset\nchannel",c="#b03a2e",tp=(63,47))
arr((30,17),(40,26))
arr((63,26),(71,19),"adapt γ, ρ",c="#2e7d32",tp=(60,14))
ax.text(50,56,"Same current, two chemistries",ha="center",fontsize=12,fontweight="bold")
b=fig.add_axes([0.6,0.17,0.38,0.7])
k=["C-UDDS","D-UDDS","C-US06"]; lab=["C","D","C/US06"]; x=np.arange(3)
for i,(m,c) in enumerate([("X-EKF","#c44e52"),("IND-R","#dd8452"),("IND-AA","#55a868"),("AA-X-EKF","#222222")]):
    b.bar(x+(i-1.5)*0.2,[S[q][m]["rmse"][0] for q in k],0.2,color=c,label=m)
b.set_xticks(x); b.set_xticklabels(lab); b.set_ylabel("LFP SOC RMSE (%)"); b.set_xlabel("Scenario (Na-ion ages faster)")
b.legend(frameon=False,fontsize=9.5); b.set_title("Monte Carlo, DFN plant",fontsize=11)
fig.savefig(os.path.join(FIG, "Graphical_abstract.png"),dpi=220); fig.savefig(os.path.join(FIG, "Graphical_abstract.pdf"))
from PIL import Image; print(Image.open(os.path.join(FIG, "Graphical_abstract.png")).size)
