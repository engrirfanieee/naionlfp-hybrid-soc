import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, time
from plant import solve_current, drive_profile
SCEN = {  # name: (theta_LFP, theta_Na, dR_LFP, dR_Na)  dR = fractional growth of ohmic resistance
 "A": (1.00, 1.00, 0.00, 0.00),
 "B": (0.95, 0.88, 0.15, 0.30),
 "C": (0.90, 0.80, 0.30, 0.60),
 "D": (0.85, 0.70, 0.45, 0.90),
 "E": (0.85, 0.95, 0.45, 0.15),
}
if __name__ == "__main__":
  jobs = sys.argv[1:]
  for job in jobs:
      name, cycle = job.split(":")
      thL, thN, _, _ = SCEN[name]
      t, I, npre = drive_profile(cycle=cycle, n_rep=34 if cycle == "UDDS" else 80)
      for chem, th in [("LFP", thL)]:
          t0 = time.time()
          tt, v, q = solve_current(chem, th, t, I)
          np.savez(os.path.join(PLANT, f"plant_{name}_{cycle}_{chem}.npz"), t=tt, v=v, q=q, I=I[:len(tt)], npre=npre)
          print(job, chem, "t_end", tt[-1], "Ah", q[-1], "wall", round(time.time()-t0), flush=True)
