"""Extended Monte Carlo evaluation (all results beyond the original six-estimator comparison):
coupled resistance-adaptive filter X-EKF-R, offset ablations, capacity prior, separated and degradation-mode
aging (D-cap, D-res, F), voltage-limited informative profile (A-inf, D-inf), tuning sensitivity, filter
consistency (NEES, coverage), delivered-charge metrics and the measurement-exclusion test (tag "excl").
Uses the same random draws and seeds as evaluate.py, so overlapping results are identical.

Usage:  python evaluate_ext.py ../jobs/<jobfile>.json [n_processes]
Each job is [case, method, tag, settings]; results go to data/results/extended/<case>__<method>__<tag>.json
"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json, time
import estimators as E
from run_plants import SCEN
P = json.load(open(os.path.join(MODEL, "ecm2_params.json")))
QF = {"LFP": P["LFP"]["Q"], "Na": P["Na"]["Q"]}
R0M = {"LFP": float(np.mean(E.LF.tab[:, 1])), "Na": float(np.mean(E.NA.tab[:, 1]))}
SIG_I, SIG_V, VQ = 0.01, 1e-3, 1e-3
OUT = os.path.join(RESULTS, "extended"); os.makedirs(OUT, exist_ok=True)
CASES = ["A", "B", "C", "D", "E", "C-US06", "D-cap", "D-res", "F", "A-inf", "D-inf"]

# ---------------- cases ----------------
def case(name):
    """returns plant file paths and aging parameters (thL, thN, dRL, dRN, QL_true, QN_true)"""
    pf = lambda tag, c: os.path.join(PLANT, f"plant_{tag}_{c}.npz")
    if name in ("A", "B", "C", "D", "E"):
        f = {c: pf(f"{name}_UDDS", c) for c in ("LFP", "Na")}; a = SCEN[name]
    elif name == "C-US06":
        f = {c: pf("C_US06", c) for c in ("LFP", "Na")}; a = SCEN["C"]
    elif name == "D-cap":      # capacity fade of scenario D only (no resistance growth)
        f = {c: pf("D_UDDS", c) for c in ("LFP", "Na")}; a = SCEN["D"][:2] + (0.0, 0.0)
    elif name == "D-res":      # resistance growth of scenario D only (fresh capacity)
        f = {c: pf("A_UDDS", c) for c in ("LFP", "Na")}; a = (1.0, 1.0) + SCEN["D"][2:]
    elif name == "F":          # degradation modes: inventory loss + halved kinetics on top of D
        f = {c: pf("drv_F", c) for c in ("LFP", "Na")}; a = SCEN["D"]
    elif name in ("A-inf", "D-inf"):   # voltage-limited informative profile (C/4 charge, terminated at the voltage limit)
        f = {c: pf(f"inf2_{name[0]}", c) for c in ("LFP", "Na")}; a = SCEN[name[0]]
    else:
        raise ValueError(name)
    thL, thN, dRL, dRN = a
    QL, QN = QF["LFP"]*thL, QF["Na"]*thN
    if name == "F":            # true capacities of the degraded cells from C/50 discharges
        QL = float(np.load(os.path.join(PLANT, "fullcap_F_LFP.npz"))["Q"]); QN = float(np.load(os.path.join(PLANT, "fullcap_F_Na.npz"))["Q"])
    return f, (thL, thN, dRL, dRN, QL, QN)

def load(name):
    f, (thL, thN, dRL, dRN, QL, QN) = case(name)
    d = {c: np.load(f[c]) for c in ("LFP", "Na")}
    n = min(len(d["LFP"]["t"]), len(d["Na"]["t"]))
    I = d["LFP"]["I"][:n]; npre = int(d["LFP"]["npre"])
    VL = d["LFP"]["v"][:n] - I*dRL*R0M["LFP"]; VN = d["Na"]["v"][:n] - I*dRN*R0M["Na"]
    bad = np.where((VL <= 2.0) | (VN <= 2.0))[0]
    cutoff = bool(len(bad)); n = bad[0] if cutoff else n
    q = d["LFP"]["q"][:n]
    sL = 1 - q/QL; sN = 1 - d["Na"]["q"][:n]/QN
    deliv = q[-1] - q          # charge actually delivered from t until the pack reached 2.0 V (or end of data)
    return dict(I=I[:n], VL=VL[:n], VN=VN[:n], sL=sL, sN=sN, QL=QL, QN=QN, thL=thL, thN=thN,
                k0=npre, n=n, deliv=deliv, cutoff=cutoff, name=name)

# ---------------- estimators ----------------
def build(method, D, b, sN0, sL0, rng):
    """returns (list of filters, offset-known flag). Method names as in the manuscript."""
    if method in ("EKF-L", "EKF-L+b", "IND-AA", "IND-R", "X-EKF", "X-EKF-R", "AA-X-EKF"):
        return [E.make(method, sN0, sL0)], False
    if method == "IND-AA|b-known":     # independent adaptive filters, true offset subtracted (perfect calibration)
        return [E.make("IND-AA", sN0, sL0)], True
    if method == "X-EKF|b-known":      # nominal coupled filter with the true offset subtracted -> no offset state left
        kk = E.cellkeys("N") + E.cellkeys("L")
        return [E.EKF(kk, [sN0, 0, 0, sL0, 0, 0], [E.P_S, E.P_V, E.P_V]*2, [E.Q_S, E.Q_V, E.Q_V]*2,
                      ["N", "L"], [E.SIG["N"]**2, E.SIG["L"]**2])], True
    if method == "IND-AA-b":           # two independent adaptive filters, each with its own (non-shared) offset state
        return [E.make_single("N", sN0), E.make_single("L", sL0)], False
    if method == "AA-X-EKF|b-calibrated":   # shared offset constrained by an offline calibration (1 mA residual)
        f = E.make("AA-X-EKF", sN0, sL0); i = f.k["b"]
        f.x[i] = b + rng.normal(0, 1e-3); f.P[i, i] = (1e-3)**2; f.Qd[i, i] = 1e-15
        return [f], False
    if method == "AA-X-EKF|capacity-prior": # capacity prior from a periodic reference capacity check (+-3 %)
        f = E.make("AA-X-EKF", sN0, sL0)
        for c, th in (("N", D["thN"]), ("L", D["thL"])):
            i = f.k["g"+c]; g = (1/th)*(1 + rng.uniform(-0.03, 0.03))
            f.x[i] = g; f.P[i, i] = (0.03*g)**2
        return [f], False
    raise ValueError(method)

def run(D, method, b, eN, eL, seed):
    rng = np.random.default_rng(seed); k0, n = D["k0"], D["n"]
    Im = D["I"] + b + rng.normal(0, SIG_I, n)
    zN = np.round((D["VN"] + rng.normal(0, SIG_V, n))/VQ)*VQ
    zL = np.round((D["VL"] + rng.normal(0, SIG_V, n))/VQ)*VQ
    if getattr(E, "EXCL", False): zN = np.where(zN > 4.2, np.nan, zN)   # measurement-exclusion test: discard Na samples above 4.2 V
    sN0 = float(np.clip(D["sN"][k0] + eN, 0, 1)); sL0 = float(np.clip(D["sL"][k0] + eL, 0, 1))
    m = n - k0
    o = dict(sL=np.empty(m), sN=np.full(m, np.nan), QL=np.full(m, E.LF.Q), QN=np.full(m, E.NA.Q),
             b=np.full(m, np.nan), sdL=np.full(m, np.nan), sdN=np.full(m, np.nan))
    if method == "CC":
        o["sL"] = E.coulomb(Im[k0:], 1.0, sL0); return o
    prng = np.random.default_rng(seed + 7919)
    filt, oracle = build(method, D, b, sN0, sL0, prng)
    Iu = Im - b if oracle else Im
    for j, kk in enumerate(range(k0, n)):
        for f in filt:
            z = np.array([zN[kk] if c == "N" else zL[kk] for c in f.meas])
            x, sd = f.step(Iu[kk], z); k = f.k
            if "sL" in k: o["sL"][j] = x[k["sL"]]; o["sdL"][j] = sd[k["sL"]]
            if "sN" in k: o["sN"][j] = x[k["sN"]]; o["sdN"][j] = sd[k["sN"]]
            if "b" in k and ("sL" in k): o["b"][j] = x[k["b"]]
            if "gL" in k: o["QL"][j] = E.LF.Q/x[k["gL"]]
            if "gN" in k: o["QN"][j] = E.NA.Q/x[k["gN"]]
    return o

def metrics(D, o, conv=3600):
    k0 = D["k0"]; sL = D["sL"][k0:]; sN = D["sN"][k0:]; w = slice(conv, None)
    e = o["sL"] - sL; hasN = not np.all(np.isnan(o["sN"]))
    r = dict(rmse=float(np.sqrt(np.mean(e[w]**2))*100), maxae=float(np.max(np.abs(e[w]))*100), final=float(e[-1]*100),
             QL=float(o["QL"][-1]), QN=float(o["QN"][-1]))
    if hasN:
        eN = o["sN"] - sN
        r.update(rmseN=float(np.sqrt(np.mean(eN[w]**2))*100), maxaeN=float(np.max(np.abs(eN[w]))*100))
        rdc_true = np.minimum(sN*D["QN"], sL*D["QL"]); rdc_hat = np.minimum(o["sN"]*o["QN"], o["sL"]*o["QL"])
        deliv = D["deliv"][k0:]
        r.update(rdc_rmse=float(np.sqrt(np.mean((rdc_hat-rdc_true)[w]**2))*1000),
                 del_rmse=float(np.sqrt(np.mean((rdc_hat-deliv)[w]**2))*1000),
                 gap_rms=float(np.sqrt(np.mean((rdc_true-deliv)[w]**2))*1000),
                 gap_mean=float(np.mean((rdc_true-deliv)[w])*1000))
    if not np.all(np.isnan(o["sdL"])):
        zl = e[w]/o["sdL"][w]; r.update(neesL=float(np.mean(zl**2)), cov95L=float(np.mean(np.abs(zl) <= 1.96)))
    if hasN and not np.all(np.isnan(o["sdN"])):
        zn = (o["sN"]-sN)[w]/o["sdN"][w]; r.update(neesN=float(np.mean(zn**2)), cov95N=float(np.mean(np.abs(zn) <= 1.96)))
    if not np.all(np.isnan(o["b"])): r["b"] = float(o["b"][-1])
    return r

def draws(nmc):
    rng = np.random.default_rng(2026)
    return [(rng.uniform(-0.010, 0.010), rng.uniform(-0.15, 0.15), rng.uniform(-0.15, 0.15)) for _ in range(nmc)]

def job(args):
    """args = (case, method, tag, settings); settings: dict of estimators.py globals to override
    (S_REF, OUT_OF_RANGE, G_LO, G_HI, R_LO, R_HI, Q_S, SIG_N, SIG_L, EXCL)"""
    name, method, tag, sett = args
    for kk, v in sett.items():
        if kk == "SIG_N": E.SIG["N"] = v
        elif kk == "SIG_L": E.SIG["L"] = v
        else: setattr(E, kk, v)
    D = load(name); res = []; t0 = time.time()
    for i, (b, eN, eL) in enumerate(draws(20)):
        r = metrics(D, run(D, method, b, eN, eL, seed=1000+i)); r.update(b_true=b, eN=eN, eL=eL); res.append(r)
    out = dict(case=name, method=method, tag=tag, settings=sett, cutoff=D["cutoff"],
               hours=(D["n"]-D["k0"])/3600, sL_end=float(D["sL"][-1]), sN_end=float(D["sN"][-1]), runs=res)
    fn = os.path.join(OUT, f"{name}__{method.replace('|', '~')}__{tag}.json")
    json.dump(out, open(fn, "w"))
    a = np.array([x["rmse"] for x in res])
    return f"{name:7s} {method:24s} {tag:10s} L-RMSE {a.mean():.2f}  wall {time.time()-t0:.0f}s"

if __name__ == "__main__":
    import multiprocessing as mp
    jobs = json.load(open(sys.argv[1])); ncpu = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    with mp.Pool(ncpu, maxtasksperchild=1) as p:
        for s in p.imap_unordered(job, [tuple(j) for j in jobs]): print(s, flush=True)
