"""Regenerative voltage excursions above 4.2 V (Section 3.3) and the measurement-exclusion test (Section 4.6, Table 12).
1) statistics of the Na-ion samples above 4.2 V per case -> data/results/regen_exc.json
2) paired AA-X-EKF - IND-AA differences with excluded samples (tag "excl") -> data/results/excl_eff.json
Run after: python evaluate_ext.py ../jobs/jobs_exclusion.json"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json
from scipy.stats import wilcoxon
import evaluate_ext as V
out = {}
for c in V.CASES:
    D = V.load(c); v = D["VN"]; k0 = D["k0"]; m = v > 4.2
    runs = []; cur = 0
    for x in m:
        if x: cur += 1
        elif cur: runs.append(cur); cur = 0
    if cur: runs.append(cur)
    out[c] = dict(n_s=int(m.sum()), frac=float(m.mean()*100), events=len(runs), maxlen=max(runs) if runs else 0,
                  vmax=float(v.max()), eval_s=int(m[k0+3600:].sum()), hours=len(v)/3600,
                  zmin_exc=float(D["sN"][m].min()) if m.any() else None)
    print(c, out[c])
json.dump(out, open(os.path.join(RESULTS, "regen_exc.json"), "w"), indent=1)
rng = np.random.default_rng(1); eff = {}
L = lambda c, m: np.array([r["rmse"] for r in json.load(open(os.path.join(RESULTS, "extended", f"{c}__{m}__excl.json")))["runs"]])
for c in ["A", "B", "C", "D", "E", "C-US06"]:
    d = L(c, "AA-X-EKF") - L(c, "IND-AA"); bs = [rng.choice(d, 20).mean() for _ in range(10000)]
    eff[c] = dict(mean=float(d.mean()), lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)),
                  wins=int((d < 0).sum()), p=float(wilcoxon(L(c, "AA-X-EKF"), L(c, "IND-AA")).pvalue))
    print(c, eff[c])
json.dump(eff, open(os.path.join(RESULTS, "excl_eff.json"), "w"), indent=1)
