"""Paired effect sizes of AA-X-EKF against the two designated comparators IND-AA and IND-R (Table 8):
mean difference with bootstrap 95 % CI, Hodges-Lehmann estimate, matched-pairs rank-biserial correlation,
Wilcoxon signed-rank test with Holm adjustment over the six cases. Output: data/results/effects.json"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json
from scipy.stats import wilcoxon, rankdata
CASES = [("A","UDDS"),("B","UDDS"),("C","UDDS"),("D","UDDS"),("E","UDDS"),("C","US06")]
def hl(d):   # Hodges-Lehmann estimator of the paired location shift
    w = [(d[i]+d[j])/2 for i in range(len(d)) for j in range(i, len(d))]; return float(np.median(w))
def rbc(d):  # matched-pairs rank-biserial correlation
    r = rankdata(np.abs(d)); return float((r[d > 0].sum() - r[d < 0].sum())/r.sum())
rng = np.random.default_rng(1)
rows = []
for comp in ["IND-AA", "IND-R"]:
    for metric in ["rmse", "maxae"]:
        for s, c in CASES:
            R = json.load(open(os.path.join(RESULTS, "montecarlo", f"mc_{s}_{c}.json")))
            a = np.array([r[metric] for r in R["AA-X-EKF"]]); b = np.array([r[metric] for r in R[comp]]); d = a - b
            bs = np.array([rng.choice(d, len(d)).mean() for _ in range(10000)])
            p = wilcoxon(a, b).pvalue
            rows.append(dict(comp=comp, metric=metric, case=f"{s}-{c}", mean_AA=float(a.mean()), mean_comp=float(b.mean()),
                             mean_diff=float(d.mean()), ci_lo=float(np.percentile(bs, 2.5)), ci_hi=float(np.percentile(bs, 97.5)),
                             hl=hl(d), rbc=rbc(d), wins=int((d < 0).sum()), p=float(p)))
# Holm correction within each (comparator, metric) family of six scenario tests
for comp in ["IND-AA", "IND-R"]:
    for metric in ["rmse", "maxae"]:
        fam = [r for r in rows if r["comp"] == comp and r["metric"] == metric]
        order = np.argsort([r["p"] for r in fam]); m = len(fam); run = 0
        for rank, i in enumerate(order):
            run = max(run, min(1, (m - rank)*fam[i]["p"])); fam[i]["p_holm"] = run
json.dump(rows, open(os.path.join(RESULTS, "effects.json"), "w"), indent=1)
for r in rows:
    print(f'{r["comp"]:8s} {r["metric"]:5s} {r["case"]:8s} AA {r["mean_AA"]:.2f} vs {r["mean_comp"]:.2f}  d {r["mean_diff"]:+.2f} [{r["ci_lo"]:+.2f},{r["ci_hi"]:+.2f}] HL {r["hl"]:+.2f} rbc {r["rbc"]:+.2f} wins {r["wins"]}/20 p {r["p"]:.1e} holm {r["p_holm"]:.1e}')
