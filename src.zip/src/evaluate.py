"""Monte Carlo evaluation of SOC/capacity estimators on DFN plant data."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json, time
from estimators import make, coulomb, NA, LF
from run_plants import SCEN
P = json.load(open(os.path.join(MODEL, "ecm2_params.json")))
QF = {"LFP": P["LFP"]["Q"], "Na": P["Na"]["Q"]}
R0M = {"LFP": float(np.mean(LF.tab[:, 1])), "Na": float(np.mean(NA.tab[:, 1]))}
SIG_I, SIG_V, VQ = 0.01, 1e-3, 1e-3   # current noise [A], voltage noise [V], ADC quantum [V]
METHODS = ["CC", "EKF-L", "IND-AA", "IND-R", "X-EKF", "AA-X-EKF"]   # original six; the coupled X-EKF-R is run by evaluate_ext.py

def load(name, cycle):
    thL, thN, dRL, dRN = SCEN[name]
    d = {c: np.load(os.path.join(PLANT, f"plant_{name}_{cycle}_{c}.npz")) for c in ("LFP", "Na")}
    n = min(len(d["LFP"]["t"]), len(d["Na"]["t"]))
    I = d["LFP"]["I"][:n]; npre = int(d["LFP"]["npre"])
    VL = d["LFP"]["v"][:n] - I*dRL*R0M["LFP"]; VN = d["Na"]["v"][:n] - I*dRN*R0M["Na"]
    # end of usable drive: first sample at which either terminal voltage reaches 2.0 V
    bad = np.where((VL <= 2.0) | (VN <= 2.0))[0]
    n = bad[0] if len(bad) else n
    QL, QN = QF["LFP"]*thL, QF["Na"]*thN
    sL = 1 - d["LFP"]["q"][:n]/QL; sN = 1 - d["Na"]["q"][:n]/QN
    return dict(I=I[:n], VL=VL[:n], VN=VN[:n], sL=sL, sN=sN, QL=QL, QN=QN, k0=npre, n=n)

def run(D, method, b, eN, eL, seed):
    rng = np.random.default_rng(seed)
    k0, n = D["k0"], D["n"]
    Im = D["I"] + b + rng.normal(0, SIG_I, n)
    zN = np.round((D["VN"] + rng.normal(0, SIG_V, n))/VQ)*VQ
    zL = np.round((D["VL"] + rng.normal(0, SIG_V, n))/VQ)*VQ
    sN0 = float(np.clip(D["sN"][k0] + eN, 0, 1)); sL0 = float(np.clip(D["sL"][k0] + eL, 0, 1))
    m = n - k0
    out = dict(sL=np.empty(m), sN=np.full(m, np.nan), QL=np.full(m, LF.Q), QN=np.full(m, NA.Q),
               b=np.full(m, np.nan), sdL=np.full(m, np.nan))
    if method == "CC":
        out["sL"] = coulomb(Im[k0:], 1.0, sL0); return out
    f = make(method, sN0, sL0); k = f.k
    for j, kk in enumerate(range(k0, n)):
        z = np.array([zN[kk], zL[kk]]) if len(f.meas) == 2 else np.array([zL[kk]])
        x, sd = f.step(Im[kk], z)
        out["sL"][j] = x[k["sL"]]; out["sdL"][j] = sd[k["sL"]]
        if "sN" in k: out["sN"][j] = x[k["sN"]]
        if "b" in k: out["b"][j] = x[k["b"]]
        if "gL" in k: out["QL"][j] = LF.Q/x[k["gL"]]
        if "gN" in k: out["QN"][j] = NA.Q/x[k["gN"]]
    return out

def metrics(D, o, conv=3600):
    k0 = D["k0"]; sL = D["sL"][k0:]; sN = D["sN"][k0:]
    e = o["sL"] - sL; w = slice(conv, None)
    rdc_true = np.minimum(sN*D["QN"], sL*D["QL"])
    sNh = o["sN"] if not np.all(np.isnan(o["sN"])) else None
    rdc_hat = np.minimum(sNh*o["QN"], o["sL"]*o["QL"]) if sNh is not None else np.full_like(o["sL"], np.nan)
    er = rdc_hat - rdc_true
    eN = o["sN"] - sN
    rmseN = float(np.sqrt(np.mean(eN[w]**2))*100) if not np.all(np.isnan(o["sN"])) else None
    return dict(rmseN=rmseN, rmse=float(np.sqrt(np.mean(e[w]**2))*100), maxae=float(np.max(np.abs(e[w]))*100),
                final=float(e[-1]*100), rdc_rmse=float(np.sqrt(np.mean(er[w]**2))*1000),
                rdc_final=float(er[-1]*1000),
                QL=float(o["QL"][-1]), QN=float(o["QN"][-1]), b=float(o["b"][-1]) if not np.isnan(o["b"][-1]) else None, eN_final=float((o["sN"][-1]-sN[-1])*100) if not np.isnan(o["sN"][-1]) else None,
                nees=None)

if __name__ == "__main__":
    name, cycle, nmc = sys.argv[1], sys.argv[2], int(sys.argv[3])
    D = load(name, cycle)
    print(name, cycle, "duration h", (D["n"]-D["k0"])/3600, "sL range", D["sL"][D["k0"]], D["sL"][-1], "sN", D["sN"][D["k0"]], D["sN"][-1])
    res = {m: [] for m in METHODS}
    rng = np.random.default_rng(2026)
    draws = [(rng.uniform(-0.010, 0.010), rng.uniform(-0.15, 0.15), rng.uniform(-0.15, 0.15)) for _ in range(nmc)]
    t0 = time.time()
    for i, (b, eN, eL) in enumerate(draws):
        for m in METHODS:
            o = run(D, m, b, eN, eL, seed=1000+i)
            r = metrics(D, o); r.update(b_true=b, eN=eN, eL=eL); res[m].append(r)
    json.dump(res, open(os.path.join(RESULTS, "montecarlo", f"mc_{name}_{cycle}.json"), "w"))
    for m in METHODS:
        a = np.array([[r["rmse"], r["maxae"], abs(r["final"]), r["rdc_rmse"], r["rmseN"] if r["rmseN"] is not None else np.nan, r["QN"], r["QL"]] for r in res[m]])
        print(f"{m:9s} L-RMSE {a[:,0].mean():6.2f}±{a[:,0].std():5.2f} MaxAE {a[:,1].mean():6.2f} |final| {a[:,2].mean():6.2f} N-RMSE {a[:,4].mean():6.2f} RDC {a[:,3].mean():7.1f} QN {a[:,5].mean():.3f} QL {a[:,6].mean():.3f}")
    print("wall", round(time.time()-t0))
