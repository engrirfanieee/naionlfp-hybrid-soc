"""Physics-based (DFN) plant simulations for the LFP and sodium-ion cells of a hybrid series string.
Aging: loss of active electrode area (capacity scale theta) + added series ohmic resistance (applied in post-processing)."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import pybamm, numpy as np, warnings
warnings.filterwarnings("ignore"); pybamm.set_logging_level("ERROR")
QNOM = 2.3            # Ah, common nominal capacity of both chemistries
NA_COIN_Q = 0.0028320647415434742   # C/50 capacity of the Chayambuka2022 base parameter set [Ah]

def params(chem, theta):
    if chem == "LFP":
        p = pybamm.ParameterValues("Prada2013"); m = pybamm.lithium_ion.DFN()
        p["Electrode width [m]"] = p["Electrode width [m]"] * theta
    else:
        p = pybamm.ParameterValues("Chayambuka2022"); m = pybamm.sodium_ion.BasicDFN()
        p["Electrode width [m]"] = p["Electrode width [m]"] * (QNOM / NA_COIN_Q) * theta
        p["Nominal cell capacity [A.h]"] = QNOM
    return p, m

def solve_current(chem, theta, t, I):
    p, m = params(chem, theta)
    p["Current function [A]"] = pybamm.Interpolant(t, I, pybamm.t, interpolator="linear")
    s = pybamm.Simulation(m, parameter_values=p, solver=pybamm.CasadiSolver(mode="safe", dt_max=600)).solve(t_eval=t)
    return s.t, s["Voltage [V]"].entries, s["Discharge capacity [A.h]"].entries

def full_capacity(chem, theta, C=1/50):
    p, m = params(chem, theta)
    p["Current function [A]"] = QNOM*theta*C
    s = pybamm.Simulation(m, parameter_values=p).solve([0, 1.3*3600/C])
    return s["Discharge capacity [A.h]"].entries, s["Voltage [V]"].entries

def drive_profile(cycle="UDDS", peak_C=1.0, n_rep=30, pre_soc=0.15, regen_C=0.05):
    a = np.loadtxt(pybamm.DataLoader().get_data(f"{cycle}.csv"), delimiter=",", comments="#")
    Ic = a[:, 1] / np.abs(a[:, 1]).max() * peak_C * QNOM
    Ic = np.maximum(Ic, -regen_C * QNOM)   # BMS regenerative-current derating
    T = a[-1, 0] + 1
    # pre-conditioning: C/10 discharge removing pre_soc of nominal capacity, then 30 min rest
    t_pre = int(pre_soc*10*3600)
    I_pre = np.r_[np.full(t_pre, QNOM/10), np.zeros(1800)]
    I = np.r_[I_pre, np.tile(Ic, n_rep)]
    t = np.arange(len(I), dtype=float)
    return t, I, len(I_pre)
