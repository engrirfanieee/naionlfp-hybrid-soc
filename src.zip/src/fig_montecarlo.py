"""Fig. 6: Monte Carlo results of the seven estimators (run collect.py first)."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8.5,"axes.linewidth":0.8})
D = json.load(open(os.path.join(RESULTS, "data_all.json")))
C6 = ["A","B","C","D","E","C-US06"]
M = [("CC","CC"),("EKF-L","EKF-L"),("IND-AA","IND-AA"),("IND-R","IND-R"),("X-EKF","X-EKF"),("X-EKF-R","X-EKF-R"),("AA-X-EKF","AA-X-EKF")]
col = {"CC":"0.7","EKF-L":"#4c72b0","IND-AA":"#55a868","IND-R":"#dd8452","X-EKF":"#c44e52","X-EKF-R":"#8172b2","AA-X-EKF":"#222222"}
g = lambda c,m,q: D[f"{c}|{m}|base"][q]
fig, ax = plt.subplots(1,2,figsize=(7.2,2.8)); x = np.arange(6); w = 0.115
for i,(m,lab) in enumerate(M):
    v = [g(c,m,"rmse") for c in C6]
    ax[0].bar(x+(i-3)*w, [a[0] for a in v], w, yerr=[a[1] for a in v], color=col[m], label=lab, error_kw=dict(lw=0.6, capsize=1.2))
both = [mm for mm in M if mm[0] not in ("CC","EKF-L")]
for i,(m,lab) in enumerate(both):
    r = [g(c,m,"rdc_rmse") for c in C6]
    ax[1].bar(x+(i-2)*w*1.35, [a[0] for a in r], w*1.35, yerr=[a[1] for a in r], color=col[m], error_kw=dict(lw=0.6, capsize=1.2))
for a in ax: a.set_xticks(x); a.set_xticklabels(["A","B","C","D","E","C/US06"]); a.set_xlabel("Scenario")
ax[0].set_ylabel("LFP SOC RMSE (%)"); ax[0].set_yscale("log"); ax[1].set_ylabel("Remaining-capacity RMSE (mAh)")
for a,t in zip(ax,"ab"): a.text(-0.26,1.03,f"({t})",transform=a.transAxes,fontweight="bold")
h,l = ax[0].get_legend_handles_labels(); fig.legend(h,l,loc="upper center",ncol=7,frameon=False,fontsize=7)
fig.tight_layout(rect=(0,0,1,0.91)); fig.savefig(os.path.join(FIG, "Figure_6.pdf")); fig.savefig(os.path.join(FIG, "Figure_6.png"), dpi=300)
