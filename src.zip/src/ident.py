"""ECM identification from the fresh DFN cells: pseudo-OCV (mean of C/50 charge and discharge) and
first-order RC parameters (R0, R1, tau1) fitted to HPPC-type pulses at nine SOC levels."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, pybamm, json, warnings
from scipy.optimize import least_squares
from plant import params, QNOM
warnings.filterwarnings("ignore"); pybamm.set_logging_level("ERROR")

def pseudo_ocv(chem):
    p, m = params(chem, 1.0)
    exp = pybamm.Experiment(["Discharge at C/50 until {} V".format(p["Lower voltage cut-off [V]"]),
                             "Rest for 2 hours",
                             "Charge at C/50 until {} V".format(p["Upper voltage cut-off [V]"] if chem=="LFP" else 4.118)])
    s = pybamm.Simulation(m, parameter_values=p, experiment=exp).solve()
    d = s.cycles[0]; c = s.cycles[2]
    qd = d["Discharge capacity [A.h]"].entries; vd = d["Voltage [V]"].entries
    qc = c["Discharge capacity [A.h]"].entries; vc = c["Voltage [V]"].entries
    Q = qd[-1] - qd[0]
    socd = 1 - (qd - qd[0]) / Q
    socc = 1 - (qc - qd[0]) / Q
    grid = np.linspace(0, 1, 201)
    od = np.interp(grid, socd[::-1], vd[::-1]); oc = np.interp(grid, np.sort(socc), vc[np.argsort(socc)])
    return grid, 0.5*(od+oc), od, oc, Q

def hppc(chem, Q):
    p, m = params(chem, 1.0)
    steps = ["Discharge at C/10 for 1 hour", "Rest for 1 hour"]
    for k in range(8):
        steps += ["Discharge at 0.5C for 30 seconds", "Rest for 120 seconds",
                  "Charge at 0.5C for 30 seconds", "Rest for 120 seconds",
                  "Discharge at C/5 for 30 minutes", "Rest for 1 hour"]
    s = pybamm.Simulation(m, parameter_values=p, experiment=pybamm.Experiment(steps, period="1 second")).solve()
    t = s["Time [s]"].entries; v = s["Voltage [V]"].entries; I = s["Current [A]"].entries; q = s["Discharge capacity [A.h]"].entries
    return t, v, I, q

def fit_pulse(t, v, I, ocv_fn=None, soc0=None, Q=None):
    """Fit V = V_rest - I*R0 - v1, dv1/dt = -v1/tau + I/C1 on a pulse+rest window"""
    v_rest = v[0]
    qk = np.concatenate([[0], np.cumsum(0.5*(I[1:]+I[:-1])*np.diff(t))])/3600.0
    drift = ocv_fn(soc0 - qk/Q) - ocv_fn(soc0)
    def model(x):
        R0, R1, tau = x
        v1 = 0.0; out = np.empty_like(v)
        for k in range(len(t)):
            if k > 0:
                dt = t[k]-t[k-1]; a = np.exp(-dt/tau)
                v1 = a*v1 + R1*(1-a)*I[k]
            out[k] = v_rest + drift[k] - I[k]*R0 - v1
        return out
    r = least_squares(lambda x: model(x) - v, [0.05, 0.05, 20.0], bounds=([1e-5, 1e-5, 1.0], [2.0, 2.0, 2000.0]))
    return r.x, np.sqrt(np.mean(r.fun**2))

if __name__ == "__main__":
    out = {}
    for chem in ["LFP", "Na"]:
        g, _pocv, od, oc, Q = pseudo_ocv(chem)
        from thermo_ocv import thermo
        g, ocv, _ = thermo(chem, Q)
        t, v, I, q = hppc(chem, Q)
        soc = 1 - q / Q
        # locate pulse windows: start of each 0.5C discharge pulse
        starts = [k for k in range(1, len(I)) if I[k] > 0.4*QNOM and I[k-1] < 0.01 * QNOM]
        rows = []
        for k0 in starts:
            w = slice(k0-1, k0+150)
            x, rmse = fit_pulse(t[w]-t[k0-1], v[w], I[w], lambda z: np.interp(z, g, ocv), soc[k0-1], Q)
            rows.append([float(soc[k0]), *map(float, x), float(rmse)])
        out[chem] = dict(soc=g.tolist(), ocv=ocv.tolist(), ocv_dis=od.tolist(), ocv_chg=oc.tolist(), Q=float(Q), ecm=rows)
        print(chem, "Q", Q); [print("  SOC %.2f R0 %.4f R1 %.4f tau %.1f  rmse %.2e" % tuple(r)) for r in rows]
    json.dump(out, open(os.path.join(MODEL, "ecm_params.json"), "w"))
