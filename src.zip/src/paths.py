"""Repository-relative paths used by all scripts."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLANT = os.path.join(ROOT, "data", "plant")      # DFN plant simulations (*.npz)
MODEL = os.path.join(ROOT, "data", "model")      # identified OCV / ECM parameters (*.json)
RESULTS = os.path.join(ROOT, "data", "results")  # Monte Carlo results and statistics (*.json)
FIG = os.path.join(ROOT, "figures")
for d in (PLANT, MODEL, RESULTS, FIG):
    os.makedirs(d, exist_ok=True)
