import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8})
fig, ax = plt.subplots(figsize=(7.2,3.0)); ax.set_xlim(0,101.5); ax.set_ylim(0,44); ax.axis("off")
def box(x,y,w,h,t,fc,ec="k",fs=7.6):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.4,rounding_size=1.2",fc=fc,ec=ec,lw=0.9))
    ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=fs)
def arr(x1,y1,x2,y2,t=None,dx=0,dy=1.2):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=9,lw=0.9,color="k"))
    if t: ax.text((x1+x2)/2+dx,(y1+y2)/2+dy,t,ha="center",fontsize=7)
box(2,24,17,12,"Series string\n(shared current $i$)","#eeeeee")
box(23,30,19,7,"Na-ion cell\n(NVPF | hard carbon)","#f6d5d1",fs=7)
box(23,21,19,7,"LFP cell\n(LFP | graphite)","#d6e2f0",fs=7)
box(2,6,17,10,"Current sensor\n$i_m = i + b + \\eta_i$","#fff6d5")
arr(19,30,24,33.5); arr(19,30,24,24.5); arr(10.5,24,10.5,16.5)
box(48,4,26,34.5,"","#ffffff")
ax.text(61,40.0,"Aging-aware cross-chemistry EKF",ha="center",fontsize=8,fontweight="bold")
box(50,26,22,7,"Na-ion 2RC ECM\n$z_N, v_{1N}, v_{2N}, \\gamma_N, \\rho_N$","#f6d5d1",fs=7)
box(50,16,22,7,"LFP 2RC ECM\n$z_L, v_{1L}, v_{2L}, \\gamma_L, \\rho_L$","#d6e2f0",fs=7)
box(50,7,22,6,"Shared offset state $b$\n(couples both cells)","#fff6d5",fs=7)
arr(41,33.5,50,30,"$y_N$",dy=1.6); arr(41,24.5,50,19.5,"$y_L$",dy=1.6); arr(19,11,50,10,"$i_m$",dy=1.0)
box(78,24,22,12,"Slope- and validity-aware\nmeasurement weighting\n$R_c\\,\\max[1,(S_{\\rm ref}/|U_c'|)^2]$","#f2f2f2",fs=6.6)
box(78,6,22,14,"Outputs\n$\\hat z_L$, $\\hat z_N$, $\\hat Q_N$, $\\hat Q_L$\n$\\hat b$, pack remaining\ncapacity","#e8f3e8",fs=7)
arr(78,30,74,30); arr(74,13,78,13)
fig.savefig(os.path.join(FIG, "Figure_1.pdf"), bbox_inches="tight"); fig.savefig(os.path.join(FIG, "Figure_1.png"), dpi=300, bbox_inches="tight")
