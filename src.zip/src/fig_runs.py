import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, matplotlib, json
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from evaluate import load, run
from estimators import LF
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8.5,"axes.linewidth":0.8})
B, EN, EL, SEED = 0.008, -0.10, -0.10, 1
D = load("C", "UDDS"); k0, n = D["k0"], D["n"]; th = (np.arange(n-k0))/3600
M = ["CC","EKF-L","IND-AA","X-EKF","IND-R","AA-X-EKF"]
col = {"CC":"0.55","EKF-L":"#4c72b0","IND-AA":"#55a868","X-EKF":"#c44e52","IND-R":"#dd8452","AA-X-EKF":"#000000"}
O = {m: run(D, m, B, EN, EL, SEED) for m in M}
# ---- Figure 3: plant data, scenario C
fig, ax = plt.subplots(1,3,figsize=(7.2,2.4))
t1 = np.arange(1370); ax[0].plot(t1/60, D["I"][k0:k0+1370], color="k", lw=0.7)
ax[0].set_xlabel("Time (min)"); ax[0].set_ylabel("Current (A)")
ax[1].plot(th, D["VN"][k0:n], color="#b03a2e", lw=0.3, label="Na-ion"); ax[1].plot(th, D["VL"][k0:n], color="#1f4e79", lw=0.3, label="LFP")
ax[1].set_xlabel("Time (h)"); ax[1].set_ylabel("Terminal voltage (V)"); ax[1].legend(frameon=False, fontsize=7, loc="lower left")
ax[2].plot(th, D["sN"][k0:n]*100, color="#b03a2e", lw=1.2, label="Na-ion"); ax[2].plot(th, D["sL"][k0:n]*100, color="#1f4e79", lw=1.2, label="LFP")
ax[2].set_xlabel("Time (h)"); ax[2].set_ylabel("Reference SOC (%)"); ax[2].legend(frameon=False, fontsize=7)
for a,t in zip(ax,"abc"): a.text(-0.30,1.04,f"({t})",transform=a.transAxes,fontweight="bold")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Figure_4.pdf")); fig.savefig(os.path.join(FIG, "Figure_4.png"),dpi=300)
# ---- Figure 4: estimation errors and the offset channel
fig, ax = plt.subplots(1,3,figsize=(7.2,2.5))
for m in M:
    ax[0].plot(th, (O[m]["sL"]-D["sL"][k0:n])*100, color=col[m], lw=1.0 if m!="AA-X-EKF" else 1.5, label=m)
    if not np.all(np.isnan(O[m]["sN"])): ax[1].plot(th, (O[m]["sN"]-D["sN"][k0:n])*100, color=col[m], lw=1.0 if m!="AA-X-EKF" else 1.5)
sd = O["AA-X-EKF"]["sdL"]*100
ax[0].fill_between(th, -3*sd, 3*sd, color="0.85", lw=0, zorder=0)
ax[0].set_ylim(-30,30); ax[1].set_ylim(-30,30)
ax[0].set_xlabel("Time (h)"); ax[0].set_ylabel("LFP SOC error (%)"); ax[0].legend(frameon=False, fontsize=6, ncol=2, loc="upper left")
ax[1].set_xlabel("Time (h)"); ax[1].set_ylabel("Na-ion SOC error (%)")
xe = O["X-EKF"]; e_meas = (xe["sL"]-D["sL"][k0:n])*100
pred = np.cumsum(xe["b"]-B)/3600/LF.Q*100 + e_meas[0]
ax[2].plot(th, e_meas, color=col["X-EKF"], lw=1.2, label="X-EKF error")
ax[2].plot(th, pred, color="k", lw=1.0, ls="--", label=r"$\int(\hat b-b)\,dt/Q_L$")
ax2 = ax[2].twinx(); ax2.plot(th, xe["b"]*1000, color="0.6", lw=0.8); ax2.set_ylabel(r"$\hat b$ (mA)", color="0.45")
ax[2].set_xlabel("Time (h)"); ax[2].set_ylabel("LFP SOC error (%)"); ax[2].legend(frameon=False, fontsize=6.5, loc="lower right")
for a,t in zip(ax,"abc"): a.text(-0.30,1.04,f"({t})",transform=a.transAxes,fontweight="bold")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Figure_5.pdf")); fig.savefig(os.path.join(FIG, "Figure_5.png"),dpi=300)
w = slice(3600, None)
dsL = np.abs(np.interp(D["sL"][k0:n], LF.g, LF.docv))/100*1000
tk = int(4.5*3600)
wp = slice(0, tk)
print("knee entry h", tk/3600, "plateau-window corr", np.corrcoef(e_meas[wp], pred[wp])[0,1], "rms diff", np.sqrt(np.mean((e_meas-pred)[wp]**2)), "err at knee", e_meas[tk-1], pred[tk-1])
print("offset-channel check: corr", np.corrcoef(e_meas[w], pred[w])[0,1], "rms diff", np.sqrt(np.mean((e_meas-pred)[w]**2)), "max |e|", np.abs(e_meas).max())
for m in M:
    e=(O[m]["sL"]-D["sL"][k0:n])*100; print(m, "RMSE", np.sqrt(np.mean(e[w]**2)), "final", e[-1], "QN", O[m]["QN"][-1], "QL", O[m]["QL"][-1])
