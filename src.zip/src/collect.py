"""Collects every number used in the tables of the manuscript into data/results/data_all.json:
means and standard deviations over the 20 realisations for each case|method|tag, the identifiability results,
effect sizes, excursion statistics and case descriptors (Table 2).
Key format: "<case>|<method>|<tag>", e.g. "D|AA-X-EKF|base"; each metric is [mean, std]."""
import os, sys, glob; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json
import evaluate_ext as V
R = {}
for fn in glob.glob(os.path.join(RESULTS, "extended", "*__*.json")):
    d = json.load(open(fn)); key = f'{d["case"]}|{d["method"]}|{d["tag"]}'; agg = {}
    for m in d["runs"][0]:
        if m in ("b_true", "eN", "eL"): continue
        v = np.array([r.get(m) if r.get(m) is not None else np.nan for r in d["runs"]], float)
        agg[m] = [float(np.nanmean(v)), float(np.nanstd(v))]
    agg.update(cutoff=d["cutoff"], hours=d["hours"], sL_end=d["sL_end"], sN_end=d["sN_end"]); R[key] = agg
for s, c in [("A","UDDS"),("B","UDDS"),("C","UDDS"),("D","UDDS"),("E","UDDS"),("C","US06")]:
    case = s if c == "UDDS" else "C-US06"
    for m, runs in json.load(open(os.path.join(RESULTS, "montecarlo", f"mc_{s}_{c}.json"))).items():
        k = f"{case}|{m}|base"
        if k in R: continue
        R[k] = {q: [float(np.nanmean(v)), float(np.nanstd(v))] for q in ("rmse", "maxae", "rmseN", "rdc_rmse", "QN", "QL")
                for v in [np.array([r.get(q) if r.get(q) is not None else np.nan for r in runs], float)]}
for name, f in (("_fim", "fim.json"), ("_eff", "effects.json"), ("_regen", "regen_exc.json"), ("_excl_eff", "excl_eff.json")):
    R[name] = json.load(open(os.path.join(RESULTS, f)))
cases = {}
for c in V.CASES:
    D = V.load(c); k0 = D["k0"]
    cases[c] = dict(zL0=float(D["sL"][k0]*100), zL1=float(D["sL"][-1]*100), zN0=float(D["sN"][k0]*100), zN1=float(D["sN"][-1]*100),
                    hours=(D["n"]-k0)/3600, cutoff=D["cutoff"], QL=D["QL"], QN=D["QN"], VNmax=float(D["VN"].max()), VLmax=float(D["VL"].max()))
R["_cases"] = cases
def clean(o):
    if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
    if isinstance(o, list): return [clean(v) for v in o]
    if isinstance(o, float) and np.isnan(o): return None
    return o
json.dump(clean(R), open(os.path.join(RESULTS, "data_all.json"), "w"), indent=0)
print(len(R), "entries written to data/results/data_all.json")
