"""Thermodynamic OCV(SOC) from electrode OCP functions and charge-balanced stoichiometry windows."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, pybamm, warnings; warnings.filterwarnings("ignore")
from plant import params
F = 96485.33212
def electrode_Q(p, e):
    E = "Negative" if e=="n" else "Positive"
    A = p["Electrode height [m]"]*p["Electrode width [m]"]
    eps = p[f"{E} electrode active material volume fraction"]
    L = p[f"{E} electrode thickness [m]"]; cmax = p[f"Maximum concentration in {E.lower()} electrode [mol.m-3]"]
    return F*eps*L*A*cmax/3600, cmax
def ocp(p, e, sto):
    E = "Negative" if e=="n" else "Positive"
    f = p[f"{E} electrode OCP [V]"]
    out = []
    for s in np.atleast_1d(sto):
        val = f(pybamm.Scalar(float(s))) if callable(f) else f
        try: out.append(float(np.ravel(val.evaluate())[0]))
        except Exception:
            out.append(float(np.ravel(p.process_symbol(val).evaluate())[0]))
    return np.array(out)
def thermo(chem, Q):
    p, _ = params(chem, 1.0)
    Qn, cn = electrode_Q(p, "n"); Qp, cp = electrode_Q(p, "p")
    sn0 = p["Initial concentration in negative electrode [mol.m-3]"]/cn
    sp0 = p["Initial concentration in positive electrode [mol.m-3]"]/cp
    soc = np.linspace(0, 1, 201); ah = (1-soc)*Q
    sn = sn0 - ah/Qn; sp = sp0 + ah/Qp
    return soc, ocp(p,"p",sp) - ocp(p,"n",sn), (sn0, sn[0], sp0, sp[0], Qn, Qp)
if __name__ == "__main__":
    import json
    P = json.load(open(os.path.join(MODEL, "ecm_params.json")))
    for ch in ["LFP","Na"]:
        soc, U, info = thermo(ch, P[ch]["Q"])
        print(ch, "sto windows", [round(x,4) for x in info[:4]], "Qn,Qp", round(info[4],3), round(info[5],3))
        for x in [0.02,0.1,0.3,0.5,0.7,0.9,1.0]:
            i=np.argmin(abs(soc-x)); print("  SOC",x,"U",round(U[i],4),"dis",round(P[ch]["ocv_dis"][i],4))
