import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json
from evaluate import load
E2 = json.load(open(os.path.join(MODEL, "ecm2_params.json")))
D = load("A","UDDS"); k0,n = D["k0"],D["n"]; I = D["I"]
def run(ch, s, V, R0f, branches):
    U = lambda z: np.interp(z, E2[ch]["soc"], E2[ch]["ocv"])
    vs = [0.0]*len(branches); y = np.empty(n-k0)
    for j,k in enumerate(range(k0,n)):
        y[j] = U(s[k]) - I[k]*R0f(s[k]) - sum(vs)
        vs = [np.exp(-1/tau(s[k]))*v + R(s[k])*(1-np.exp(-1/tau(s[k])))*I[k] for v,(R,tau) in zip(vs,branches)]
    e=(V[k0:n]-y)*1000; m = D["s"+("N" if ch=="Na" else "L")][k0:n]>0.10
    return np.sqrt(np.mean(e[m]**2)), e[m].mean()
for ch, s, V in [("Na", D["sN"], D["VN"]), ("LFP", D["sL"], D["VL"])]:
    r = np.array([x for x in E2[ch]["ecm2"]]); good = r[:,6] < 0.025
    sg = r[good,0]; o = np.argsort(sg)
    f = lambda col: (lambda z: np.interp(z, sg[o], r[good,col][o]))
    med = lambda col: float(np.median(r[good,col]))
    r1 = np.array(E2[ch]["ecm"]); g1 = r1[:,4] < 5e-3; o1 = np.argsort(r1[g1,0])
    R0_1 = lambda z: np.interp(z, r1[g1,0][o1], r1[g1,1][o1])
    c = {}
    c["1RC (pulse fit, median R1/tau)"] = run(ch, s, V, R0_1, [(lambda z: float(np.median(r1[g1,2])), lambda z: float(np.median(r1[g1,3])))])
    c["2RC SOC-dependent"] = run(ch, s, V, f(1), [(f(2), f(3)), (f(4), f(5))])
    c["2RC R0(SOC), median branches"] = run(ch, s, V, f(1), [(lambda z: med(2), lambda z: med(3)), (lambda z: med(4), lambda z: med(5))])
    for k,v in c.items(): print(ch, f"{k:34s} RMSE {v[0]:6.1f} mV  mean {v[1]:6.1f} mV (SOC>10%)")
