"""Second-order ECM identification (R0, R1, tau1, R2, tau2) per SOC from the HPPC-type DFN test
(0.5C pulse pair + C/5 30-min discharge + 1-h rest), using the thermodynamic OCV for the drift term."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import numpy as np, json, warnings, pybamm
from scipy.optimize import least_squares
from ident import hppc
from thermo_ocv import thermo
warnings.filterwarnings("ignore")
P = json.load(open(os.path.join(MODEL, "ecm_params.json")))

def sim2(x, t, I, s0, Q, U):
    R0, R1, t1, R2, t2, v10, v20 = x
    q = np.concatenate([[0], np.cumsum(0.5*(I[1:]+I[:-1])*np.diff(t))])/3600
    v1, v2 = v10, v20; out = np.empty_like(I)
    for k in range(len(t)):
        if k:
            dt = t[k]-t[k-1]; a1 = np.exp(-dt/t1); a2 = np.exp(-dt/t2)
            v1 = a1*v1 + R1*(1-a1)*I[k-1]; v2 = a2*v2 + R2*(1-a2)*I[k-1]
        out[k] = U(s0 - q[k]/Q) - I[k]*R0 - v1 - v2
    return out

out = {}
for chem in ["LFP", "Na"]:
    Q = P[chem]["Q"]; g, ocv, _ = thermo(chem, Q); U = lambda z: np.interp(z, g, ocv)
    t, v, I, q = hppc(chem, Q)
    soc = 1 - q/Q
    starts = [k for k in range(1, len(I)) if I[k] > 0.4*Q and I[k-1] < 0.01*Q]
    rows = []
    for k0 in starts:
        w = slice(k0-1, min(k0-1+5700, len(t)))
        tw, vw, Iw = t[w]-t[k0-1], v[w], I[w]
        # initial state: cell rested 1 h, so start from measured rest voltage (fit offset via s0 using OCV)
        s0 = soc[k0-1]
        f = lambda x: sim2(x, tw, Iw, s0, Q, U) - vw
        best = None
        for t2g in (300.0, 1500.0, 4000.0):
            r = least_squares(f, [0.05, 0.01, 30.0, 0.02, t2g, 0.0, 0.0],
                              bounds=([1e-5, 1e-6, 1.0, 1e-6, 150.0, -0.3, -0.3], [2, 2, 150.0, 5, 2e4, 0.3, 0.3]))
            if best is None or r.cost < best.cost: best = r
        rmse = float(np.sqrt(np.mean(best.fun**2)))
        rows.append([float(s0), *map(float, best.x[:5]), rmse, float(best.x[5]), float(best.x[6])])
        print(chem, "SOC %.2f R0 %.4f R1 %.4f t1 %.0f R2 %.4f t2 %.0f v10 %.3f v20 %.3f rmse %.1f mV" % (s0, *best.x, rmse*1000), flush=True)
    out[chem] = dict(soc=g.tolist(), ocv=ocv.tolist(), Q=Q, ecm2=rows,
                     ocv_dis=P[chem]["ocv_dis"], ocv_chg=P[chem]["ocv_chg"], ecm=P[chem]["ecm"])
json.dump(out, open(os.path.join(MODEL, "ecm2_params.json"), "w"))
