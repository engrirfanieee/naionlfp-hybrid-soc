"""Fig. 3: identifiability analysis (run fim.py first)."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import PLANT, MODEL, RESULTS, FIG
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8.5,"axes.linewidth":0.8})
F=json.load(open(os.path.join(RESULTS, "fim.json"))); W=F["A|windows"]
fig,ax=plt.subplots(1,2,figsize=(7.2,2.6))
zN=np.array([w["zN"] for w in W])*100
ax[0].semilogy(zN,[w["sd_zN"] for w in W],"o-",color="#b03a2e",ms=3.5,lw=1.3,label="sodium-ion SOC")
ax[0].semilogy(zN,[w["sd_zL"] for w in W],"s-",color="#1f4e79",ms=3.5,lw=1.3,label="LFP SOC")
ax[0].invert_xaxis(); ax[0].set_xlabel("Mean sodium-ion SOC in 1 h window (%)"); ax[0].set_ylabel("Posterior std. dev. (% SOC)")
ax[0].legend(frameon=False,fontsize=7,loc="lower left")
labs=["UDDS","UDDS+rests","UDDS+charge+rest"]; x=np.arange(3); wdt=0.2
for j,(sc,al) in enumerate([("A",0.45),("D",1.0)]):
    ax[1].bar(x+(j-0.5)*2*wdt-wdt/2,[abs(F[f"{sc}|{l}"]["corr_b_gN"]) for l in labs],wdt,color="#b03a2e",alpha=al,label=r"$|r(b,\gamma_{\rm N})|$, "+sc)
    ax[1].bar(x+(j-0.5)*2*wdt+wdt/2,[abs(F[f"{sc}|{l}"]["corr_b_gL"]) for l in labs],wdt,color="#1f4e79",alpha=al,label=r"$|r(b,\gamma_{\rm L})|$, "+sc)
ax[1].set_xticks(x); ax[1].set_xticklabels(["UDDS","UDDS + rests","UDDS + charge\n(V-limited) + rest"]); ax[1].set_ylim(0,1.4); ax[1].set_yticks(np.arange(0,1.01,0.2))
ax[1].set_ylabel("Posterior correlation with offset"); ax[1].legend(frameon=False,fontsize=6.5,loc="upper center",ncol=2)
for a,t in zip(ax,"ab"): a.text(-0.2,1.02,f"({t})",transform=a.transAxes,fontweight="bold")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Figure_3.pdf")); fig.savefig(os.path.join(FIG, "Figure_3.png"), dpi=300)
